package com.example.game;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private LeaderB q;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





    }




    public void room1(View view) {
        Bundle b=new Bundle();
        b.putBooleanArray("arr", new boolean[]{true,false,false,false,false});
        Intent intent=new Intent(this, Room1.class);
        intent.putExtras(b);
        startActivity(intent);
    }


    public void leaderboard(View view) {
        Bundle b = this.getIntent().getExtras();
        q = b.getParcelable("q");
        q.sort(this);
        q.print();
    }
}