package com.example.game;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Pcgamewin extends AppCompatActivity {
    private TextView tv;
    private Code co;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pcgamewin);
        Bundle b = this.getIntent().getExtras();
        co = b.getParcelable("co");
        tv = (TextView) findViewById(R.id.tv);
        tv.setText(String.valueOf(co.getCode1()));
    }


    public void pcgame(View view) {
        finish();
    }
}