package com.example.game;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;

public class Closet1 extends AppCompatActivity {
    private boolean [] arr;
    private Chronometer chronometer;
    private boolean key = false;
    private Chronom c;

    private int screenWidth;

    private ImageView iv;

    private TextView tv1;


    private float arrowLeftX;

    private Handler handler = new Handler();
    private Timer timer = new Timer();

    private boolean tf = false;

    private Code co;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_closet1);
        Bundle b = this.getIntent().getExtras();
        //bool
        key = b.getBoolean("key");
        //new arr = prev arr
        arr = b.getBooleanArray("arr");
        //stopwatch
        chronometer = findViewById(R.id.chronometer);
        c = b.getParcelable("p");
        c.start(chronometer);
        //code
        co = b.getParcelable("co");

        tv1 = (TextView) findViewById(R.id.tv1);
        tv1.setText(String.valueOf(co.getCode2()));
        iv = (ImageButton)findViewById(R.id.iv1);
        WindowManager wm = getWindowManager();
        Display disp = wm.getDefaultDisplay();
        Point size = new Point();
        disp.getSize(size);
        screenWidth = size.x;
    }

    public void m(View view) {
        if (!tf) {
            tf = true;
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            changePos();

                        }
                    });
                }
            }, 0, 20);
        }
    }

    public void changePos(){

        int x = -600; //לשנות את המספר הזה בשביל להזיז את האוביק בציר ה X
        arrowLeftX -= 30;
        iv.setX(arrowLeftX);
        if (arrowLeftX == x){
            // Stop the timer.
            timer.cancel();
            timer = null;



        }
    }


    public void room4(View view) {
        //stopwatch
        c.stop(chronometer);
        //read bundle
        Bundle b = new Bundle();
        System.out.println(Arrays.toString(arr));
        //bundle arr and long
        b.putBooleanArray("arr", arr);
        b.putBoolean("key",key);
        b.putParcelable("p",c);
        Intent intent=new Intent();
        intent.putExtras(b);
        //finish and send result
        setResult(RESULT_OK,intent);
        finish();
    }
}