package com.example.game;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;


public class Drawer1 extends AppCompatActivity {
    private TextView tv1;
    private Code co;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawer1);
        Bundle b = this.getIntent().getExtras();
        co = b.getParcelable("co");
        tv1 = findViewById(R.id.tv1);
        tv1.setText(String.valueOf(co.getCode3()));

    }
}


