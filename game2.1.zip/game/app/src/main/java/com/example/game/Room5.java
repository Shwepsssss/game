package com.example.game;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Chronometer;

import java.util.Arrays;

public class Room5 extends AppCompatActivity {
    private boolean [] arr;
    private Chronometer chronometer;
    private Chronom c;
    private boolean key = false;
    private Code co;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room5);
        Bundle b = this.getIntent().getExtras();
        // new arr = prev arr
        arr = b.getBooleanArray("arr");
        arr[4] = true;
        //stopwatch
        chronometer = findViewById(R.id.chronometer);
        c = b.getParcelable("p");
        c.start(chronometer);
        //key bool
        key = b.getBoolean("key");
        //code
        co = b.getParcelable("co");
    }

    public void room3(View view) {
        //stopwatch
        c.stop(chronometer);
        //read bundle
        Bundle b = new Bundle();
        System.out.println(Arrays.toString(arr));
        //bundle arr and long
        b.putBooleanArray("arr", arr);
        b.putParcelable("p",c);
        b.putBoolean("key",key);
        Intent intent=new Intent();
        intent.putExtras(b);
        //finish and send result
        setResult(RESULT_OK,intent);
        finish();
    }

    public void h(View view) {
        Bundle b = this.getIntent().getExtras();
        System.out.println(Arrays.toString(arr));
        Hint hint = new Hint(arr,key);
        if (hint.roomCheck(this))
            if (hint.keyCheck(this))
                System.out.println("d");
    }

    public void finish(View view) {
        //stopwatch
        c.stop(chronometer);
        //read bundle
        Bundle b=this.getIntent().getExtras();
        b.putParcelable("p",c);
        Intent intent=new Intent(this, Finish.class);
        intent.putExtras(b);
        //start new activity
        startActivity(intent);


    }
}

