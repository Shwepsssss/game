package com.example.game;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Finish extends AppCompatActivity {
    private Chronom c;
    private LeaderB q = new LeaderB();
    private EditText et1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finish);
        et1 = (EditText) findViewById(R.id.et1);
        Bundle b = this.getIntent().getExtras();
        c = b.getParcelable("p");

    }

    public void submit(View view) {
        q.addScore(c.getPauseOffset(), String.valueOf(et1.getText()));
        q.print();
        Intent intent = new Intent(this,MainActivity.class);
        Bundle b=this.getIntent().getExtras();
        b.putParcelable("q",q);
        intent.putExtras(b);
        startActivity(intent);
    }
}